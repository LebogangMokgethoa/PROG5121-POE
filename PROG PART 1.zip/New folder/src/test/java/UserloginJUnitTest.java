/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lebogang.F MOKGETHOA
 * @version 1.2
 */
public class UserloginJUnitTest {
 
// Test: username correct
    @Test
    public void testUsernameCorrect() {
        Userlogin user = new Userlogin("kyl_1", "Password1", "+27838968976", "Kyle", "Smith");
        
        boolean result = user.checkUserName("kyl_1");
        
        String message = user.loginstatus(true);
        
        assertTrue(result, "Welcome < user first name > user last name > it is great to see you again");
    }
    // Test: username incorect
    @Test
    public void testUsernameIncorrect() {
        Userlogin user = new Userlogin("kyle!!!!!", "Password1!", "+27838968976", "Kyle", "Smith");
        
        boolean result = user.checkUserName("kyle!!!!");
        
        String message = user.loginstatus(false);
        
        assertFalse(result, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters ");
    }
// Test: password valid
    @Test
    public void testPasswordValid() {
        Userlogin user = new Userlogin("kyl_1", "password", "+27838968976", "kyle", "Smith");
        
        boolean result = user.checkPasswordComplexity("Ch&sec@ke99!");
        
        String message = user.loginstatus(true);
        
        assertTrue(result, "Password meets requirements");
    }
    
    // Test: password invalid
    @Test
    public void testPasswordInvalid() {
        
        boolean result = user.checkPasswordComplexity("password");
        
        String message = user.loginstatus(false);
        
        assertFalse(result, "Password is not correctly formatted, please ensure that the passsword contains, capital, special character, and a number");
        
    }
    // Test: phone correct
    @Test
    public void testPhoneCorrect() {
        Userlogin user = new Userlogin("kyl_1", "Password1!", "+27838968976","kyle", "Smith");
        
        boolean result = user.checkCellPhoneNumber("08966553");
        
        String message = user.loginstatus(true);
        
        assertFalse(result, "Cell number successfully captured");
    }
    
    // Test: phone incorrect
    @Test
    public void testPhoneIncorrect() {
        Userlogin user = new Userlogin("kyl_1", "Password1!", "08966553", "Kyle", "Smith");
        
        boolean result = user.checkCellPhoneNumber("08966553");
        
        String message = user.loginstatus(false);
        
        assertFalse(result, "Cell number is incorrectly formatted does not contain SA international code.Please correct the number and try again");
    }
    
    // Test: login success
    @Test
    public void testLoginSuccess() {
        Userlogin user = new Userlogin("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        
        boolean result = user.loginUser("kyl_1", "Passsword1!");
        
        String message = user.loginstatus(true);
        
        assertTrue(result, "Login should succeed");
    }
    
    // Test: login unseccessful
        public void testLoginFailed() {
            Userlogin user = new Userlogin("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
            
            boolean result = user.loginUser("wrongUsername", "wrongPassword");
            
            String message = user.returnloginstatus(false);
            
            assertFalse(result, "Login should fail");
            
        }
        // ----------------------------
        // Login message 
        // ------------------------------
        @Test
        public void loginMessageCorrect() {
            Userlogin user = new Userlogin("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
            
            String message = user.returnLoginStatus(true);
            
            assertEquals("Welcome Kyle Smith.it is great to see you again");
        }
        
        @Test
        public void loginMessageIncorrect() {
            Userlogin user = new Userlogin("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
            
            String message =user.returnLoginStatus(false);
            
            assertEquals("Login failed.please try again.");
                    
        }

    private void assertEquals(String login_failedplease_try_again) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

    

            
            
            
     

       
     
   









