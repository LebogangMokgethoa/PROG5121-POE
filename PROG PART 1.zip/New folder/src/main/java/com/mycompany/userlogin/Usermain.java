/*   
* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.userlogin;

import java.util.Scanner;

/**
 *
 * @author LEBOGANG.F MOKGETHOA
 *  @version 1.1
 * Handles validation, registration, login
 */
 public class Usermain { // This must match the filename // ...
 

     String username;
    String password;
    String phone;
    String firstName;
    String lastName;

    public Usermain(String username, String password, String phone, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.firstName = firstName;
        this.lastName = lastName;
    }

     // Start
     public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
         
     System.out.println("----- Register New User -----");
     System.out.print("Enter First Name: ");
     String fName = input.nextLine();
     System.out.print("Enter Last Name: ");
     String lName = input.nextLine();
     System.out.print("Enter Username: ");
     String uName = input.nextLine();
     System.out.print("Enter Password: ");
     String passW = input.nextLine();
     
     // Create the object 
     Usermain newUser = new Usermain(uName, passW, fName, lName);
     
     // Run registration check and PRINT the output
     String regStatus = newUser.registerUser();
     System.out.println("\n" + regStatus);
     
     // Only proceed to login if registration was successful
     if (regStatus.contains("successful")) {
         
         System.out.println("\n--- Login ---");
         
         System.out.print("Username: ");
         String loginUser = input.nextLine();
         System.out.println("Password: ");
         String loginPass = input.nextLine();
         
         boolean success = newUser.loginUser(loginUser, loginPass);
         
         System.out.println(newUser.returnLoginStatus(success));
        }
     }

   Usermain(String uName, String passW, String fName, String lName) {
        }
     
     // Registration login
    public String registerUser() {

        if (!username.contains("_")) {
            return "Username must contain an underscore (_).";
        }
        if (password.length() <= 8) {
            return "Password is too short!";
        }

        return "Registration successful for " + firstName + " " + lastName;
    }

    public boolean loginUser(String enteredUser, String enteredPass) {
        return enteredUser.equals(username) && enteredPass.equals(password);
    }

    public String returnLoginStatus(boolean success) {
        if (success) {
            return "Login successful! Welcome " + firstName;
        } else {
            return "Login failed. Incorrect username or password.";
        }
    }
}




