/* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.userlogin;
import java.util.Scanner;

/*
*
* 
* @author LEBOGANG.F MOKGETHOA
* @version 1.0
*
*/
public class Userlogin { // This must match the filename // ...
   
        
     String username;
     String password;
     String phone;
     String firstName;
    String lastName;

    // Main method
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("---- Registration---");
        
        System.out.print("First Name: ");
        String fName = input.nextLine();
        System.out.print("Last Name: ");
        String lName = input.nextLine();
        System.out.print("Username (needs _): ");
        String uName = input.nextLine();
        System.out.print("Password: ");
        String pass = input.nextLine();
        System.out.print("Phone (+27): ");
        String cell = input.nextLine();
    
    //  Create the object using your constructor
    Userlogin newUser = new Userlogin(uName, pass, cell, fName, lName);
    
    // Registration method and PRINT the result
    
    String status = newUser.registerUser();
    System.out.println("\nRegistration Result: " + status);
    
    // Login if registration is successful
    if(status.equals("Registration successful!")) {
        System.out.println("\n---- Login ----");
        
        System.out.print("Enter username: ");
        String loginU = input.nextLine();
        System.out.print("Enter Password: ");
        String loginP = input.nextLine();
        
        boolean success = newUser.loginUser(loginU, loginP);
        
        System.out.println(newUser.returnLoginStatus(success));
       }
    }
        
        // Constructor
    public Userlogin(String username, String password, String phone, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Registration rules
    public String registerUser() {
        // Username underscore
        if (!username.contains("_")) {
            return "Username must contain an underscore (_)";
        } // 
        
            // Username length 
            if (username.length() > 5) {
            return "Username must not have more than 5 characters";
        }
        // Check password length
        if (password.length() < 8) {
            return "Password must be at least 8 characters long";
        }
            // Password complexity (Capital, Number,Special Character)
            // Using regex: [A-Z] is capital, [0-9] is a number, the rest of the symbols
            boolean hasCapital = password.matches(".*[A-Z].*");
            boolean hasDigit = password.matches(".*[0-9].*");
            boolean hasSpecial = password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
            
            if(!hasCapital || !hasDigit || !hasSpecial) {
            return "Password must have capital letter,numbers, and special characters";
        }
        
        // Check Phone prefix
        if (!phone.startsWith("+27")) {
            return "Phone number must start with SA international code (+27)";
        }
        // If it passes all the checks above:
        return "Registration successful!";
    } //

    // Login functionality
    public boolean loginUser(String enteredUser, String enteredPass) {
        return enteredUser.equals(username) && enteredPass.equals(password);
    }

    public String returnLoginStatus(boolean success) {
        if (success) {
            return "Welcome " + firstName + " " + lastName + "." + "it is great to see you again";
        } else {
            return "Login failed.Please try again.";
        }
    }
    } //


    


